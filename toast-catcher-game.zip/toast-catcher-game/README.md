# Toast Catcher Game

A Pen created on CodePen.

Original URL: [https://codepen.io/Megafry/pen/yyyZyYw](https://codepen.io/Megafry/pen/yyyZyYw).

Tap the flying toasts before they hit the ground!