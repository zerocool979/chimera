# [gsap/physics2D] ❍  8-Bit Snake Game - Challenge #4

A Pen created on CodePen.

Original URL: [https://codepen.io/filipz/pen/JoogyPM](https://codepen.io/filipz/pen/JoogyPM).

