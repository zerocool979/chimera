# Magic Egg

A Pen created on CodePen.

Original URL: [https://codepen.io/BlackStar1991/pen/yyYPEON](https://codepen.io/BlackStar1991/pen/yyYPEON).

